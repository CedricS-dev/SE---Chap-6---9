/********************************************************
# Nom ......... : redirection.c
# Rôle ........ : Fichier contenant les fonctions de redirection du mini-shell
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 29/01/2026
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 6, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/


#include "includes/sys.h"
#include "includes/redirection.h"
#include "includes/utils.h"


void cherche_redirection(char *mots[])
{
  // Pour chaque mot dans la liste de mots
  // Cherche une correspondance avec les redirections de flux
  for (int i = 0; mots[i] != NULL; i++)
    if (strcmp(mots[i], ">") == 0 || strcmp(mots[i], "1>") == 0)
      redirection(&mots[i], mots[i + 1], STDOUT_FILENO, 0);
    else if (strcmp(mots[i], ">>") == 0 || strcmp(mots[i], "1>>") == 0)
      redirection(&mots[i], mots[i + 1], STDOUT_FILENO, 1);
    else if (strcmp(mots[i], "2>") == 0)
      redirection(&mots[i], mots[i + 1], STDERR_FILENO, 0);
    else if (strcmp(mots[i], "2>>") == 0)
      redirection(&mots[i], mots[i + 1], STDERR_FILENO, 1);
    else if (strcmp(mots[i], "<") == 0)
      redirection(&mots[i], mots[i + 1], STDIN_FILENO, 2);
    else if (strcmp(mots[i], "&>") == 0 || strcmp(mots[i], ">&") == 0)
      redirection(&mots[i], mots[i + 1], 3, 0);
    else if (strcmp(mots[i], "&>>") == 0 || strcmp(mots[i], ">>&") == 0)
      redirection(&mots[i], mots[i + 1], 3, 1);
}


void redirection(char ** redirection, char * filename, int fileno, int type_redir)
{
  int fd;
  // Vérifie si le nom de fichier est correct
  if (verifie_filename(*redirection, filename) < 0)
    exit(1);

  // Choisis le type de d'ouverture du fichier en fonction de l'argument type_redir
  switch (type_redir)
  {
    case 0 :
      fd = creat(filename, S_IRWXU);
      break;
    case 1:
      fd = open(filename, O_CREAT | O_APPEND | O_WRONLY, S_IRWXU);
      break;
    case 2:
      fd = open(filename, O_RDONLY);
      break;      
  }
  
  // Si l'ouverture du fichier échoue, retourne une erreur
  if (fd == -1)
     perror_exit("Erreur : open");

  // Si l'argument fileno vaut 3, fais un dup2 sur stdout et stderr
  if (fileno == 3)
  {
    dup2(fd, STDOUT_FILENO);
    dup2(fd, STDERR_FILENO);
  }
  // Sinon, fais dup2 sur le flux correspondant à fileno
  else if (fileno < 3 && fileno >= 0)
    dup2(fd, fileno);

  // Remplace la redirection par NULL et ferme fd
  *redirection = NULL;
  close(fd);
}


int verifie_filename(char * redirection, char * filename)
{
  // Liste des différentes redirections traitées par le programme
  const char * list_redir[] = {">", "1>", ">>", "1>>", "2>", "2>>", "&>", "&>>", ">&", ">>&"};

  // S'il n'y a aucun nom de fichier, retourne une erreur 
  if (filename == NULL)
  {
    fprintf(stderr, "Erreur : aucun nom de fichier après %s\n", redirection);
    return -1;
  }

  // Si le nom de fichier correspond à une des redirections, retourne une erreur
  for (int i = 0; i < 8; i++)
    if (strcmp(filename, list_redir[i]) == 0)
    {
      fprintf(stderr, "Erreur : un nom de fichier est attendu après %s, mais la redirection %s a été trouvée à la place\n", redirection, filename);
      return -1;
    }
  
  // Retourne 0 si aucun problème n'a été détecté
  return 0;
}
