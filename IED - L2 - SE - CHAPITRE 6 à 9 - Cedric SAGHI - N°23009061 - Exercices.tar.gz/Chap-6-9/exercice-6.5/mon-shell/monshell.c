/********************************************************
# Nom ......... : monshell.c
# Rôle ........ : Fichier avec les fonctions principales du mini-shell
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 29/01/2026
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 6, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/


#include "includes/sys.h"
#include "includes/monshell.h"
#include "includes/command.h"
#include "includes/utils.h"
#include "includes/redirection.h"


int main(int argc, char *argv[])
{
  char ligne[MaxLigne];
  int status_defaut = 0;
  int *exit_status = &status_defaut;

  char *commandes[MaxMot];
  int nbr_commandes;

  // Lire et traiter la ligne de commande
  for (printf(PROMPT); fgets(ligne, sizeof(ligne), stdin) != 0; printf(PROMPT))
  {
    // Commence par découper la ligne en fonction des pipes "|"
    decouper(ligne, "|", commandes, MaxLigne),
    // Et récupère le nombre de commandes
    nbr_commandes = calcul_len(commandes);
  
    // Si le nombre de commandes est de 0, relance la boucle
    if (nbr_commandes == 0)
      continue;
    // Sinon, lance le traitement
    else
    { 
      execute_commande_et_pipe(commandes, nbr_commandes, exit_status);
      continue;
    }    
  }
  
  return 0;
}


void execute_commande_et_pipe(char *command[], int nbr_commandes, int *exit_status)
{
  int len, esperluette, tmp, etat;
  char *mots[MaxMot];

  // On retrouve le nombre de pipes en soustrayant 1 au nombre de commandes
  // S'il n'y a qu'une seule commande, le nombre de pipe est de 0
  int nbr_pipes = nbr_commandes - 1;
  int tab_pipes[nbr_pipes][2];

  // Crée les pipes et vérifie qu'il n'y a pas eu d'erreurs
  for (int i = 0; i < nbr_pipes; i++)
    if (pipe(tab_pipes[i]) < 0)
      perror_exit("Erreur : pipe");
  
  // Pour chaque commande dans la liste de commandes :
  // Découpe la commande en mots
  // et cherche les commandes natives et l'esperluette
  for (int i = 0; i < nbr_commandes; i++)
  {
    decouper(command[i], " \t\n", mots, MaxMot);
    len = calcul_len(mots);

    if (len == 0)
      continue;

    if (cherche_commande(len, mots, exit_status) == 1)
      continue;

    esperluette = cherche_esperluette(len, mots);

    // Fait un fork() pour chaque commande
    switch(tmp = fork())
    {
      // Erreur dans le fork :
      case -1:
        perror_exit("Erreur : fork");

      // Enfant :
      case 0:
        // Pour tous les pipes, sauf le dernier :
        // redirige le descripteur d'écriture du pipe actuel vers stdout
        if (i < nbr_commandes - 1)
        {
          if (dup2(tab_pipes[i][1], STDOUT_FILENO) < 0)
            perror_exit("Erreur : dup2 (STDOUT)");

          // Et ferme les entrées/sorties du pipe actuel
          close(tab_pipes[i][0]);
          close(tab_pipes[i][1]);
        }

        // Pour tous les pipes, sauf le premier :
        // redirige le descripteur de lecture du pipe précédent vers stdin
        if (i > 0)
        {
          if (dup2(tab_pipes[i-1][0], STDIN_FILENO) < 0)
            perror_exit("Erreur : dup2 (STDIN)");
          
          // Et ferme les entrées/sorties du pipe précédent
          close(tab_pipes[i-1][0]);
          close(tab_pipes[i-1][1]);
        }

        // Ferme toutes les entrées/sorties non utilisées
        for (int j = 0; j < nbr_pipes; j++)
          if ((i == 0 || j != (i - 1)) && (i == (nbr_commandes - 1) || j != i))
          {
            close(tab_pipes[j][0]);
            close(tab_pipes[j][1]);
          }

        
      // Vérifie si une redirection à été demandée avant le lancer execvp
      cherche_redirection(mots);
      execvp(mots[0], mots);
      // Si aucun exec n'a fonctionné
      fprintf(stderr, "Erreur: la commande %s n'a pas été trouvée\n", mots[0]);
      exit(1);

      // Parent : sort de la boucle
      default :
        break;
    }   
  }

  // Parent, hors de la boucle
  // Ferme tous les pipes
  for (int i = 0; i < nbr_pipes; i++)
  {
    close(tab_pipes[i][0]);
    close(tab_pipes[i][1]);
  }

  // Si une esperluette est trouvée, n'attends pas la fin de l'enfant
  for (int i = 0; i < nbr_commandes; i++)
    if (esperluette != 0)
      waitpid(-1, &etat, 0);
        
  // Récupère le statut de sortie du dernier enfant
  if (WIFEXITED(etat))
    *exit_status = WEXITSTATUS(etat);

}
