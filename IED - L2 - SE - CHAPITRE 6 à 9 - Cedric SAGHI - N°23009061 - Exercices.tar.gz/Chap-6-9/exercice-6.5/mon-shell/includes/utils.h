/********************************************************
# Nom ......... : utils.h
# Rôle ........ : Fichier en-tête de utils.c
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 22/12/2025
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 5, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/


#ifndef _UTILS_
#define _UTILS_


/**
 * @brief calcul_len  -- calcul la longueur d'une liste de mots
 * @param char *mots[] : liste de mots dont on souhaite obtenir la longueur
 * @return int : longueur de la liste de mots
*/
int calcul_len(char *mots[]);


/**
 * @brief decouper -- decouper une chaîne en liste de mots
 * @param char *ligne : ligne de texte à découper
 * @param char *separ : caractère(s) permetant de séparer les mots de la ligne
 * @param char *mots	: tableau recevant les mots après découpage
 * @param int maxmot	: nombre d'emplacement disponible dans le tableau
 * @return int : nombre de mots dans la liste
*/
int decouper(char *ligne, char *separ, char *mots[], int maxmot);

/**
 * @brief perror_exit -- lance la fonction perror() avec l'argument message
 *   puis lance exit(1)
 * @param char *message : message à afficher dans perror()  
*/
void perror_exit(char *message);


#endif
