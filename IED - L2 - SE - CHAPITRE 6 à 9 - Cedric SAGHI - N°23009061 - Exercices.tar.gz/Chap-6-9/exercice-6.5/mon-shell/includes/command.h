/********************************************************
# Nom ......... : command.h
# Rôle ........ : Fichier en-tête de command.c
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 29/01/2026
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 6, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/



#ifndef _COMMAND_
#define _COMMAND_


/** 
 * @brief moncd -- reproduit la command "cd" du shell
 * @param int len : longueur de la liste de mots
 * @param char *mots : liste de mots contenant la commande et ses arguments
 * @return : 0 si une correspondance est trouvée, sinon 1
*/
int moncd(int len, char *mots[]);


/**
 * @brief monexit -- reprodut la commande "exit" du shell
 * @param int len : longueur de la liste de mots
 * @param char *mots[] : liste de mots conteant la commande et ses arguments
 * @param int exit_status : status de sortie de la dernière commande exécutée
 * @return : status de sortie donné en argument
*/
int monexit(int len, char *mots[], int exit_status);


/**
 * @brief cherche_esperluette -- vérifie si la liste de mots se termine par une esperluette
 * @param int len : longueur de la liste de mots à traiter
 * @param char *mots[] : liste de mots à traiter
 * @return : 0 si une correspondance est trouvée, sinon 1
*/
int cherche_esperluette(int len, char *liste_mots[]);


/**
 * @brief cherche_commande -- cherche dans la ligne de commande si une commande native est entrée
 * @param int len : longueur de la liste de mots
 * @param char *mots[] : liste de mots conteant la commande et ses arguments
 * @param *int exit_status : pointeur vers le statut de sortie de la dernière commande exécutée
 * @return int : 0 si une commande est trouvée, sinon 1 
*/
int cherche_commande(int len, char *mots[], int *exit_status);


#endif
