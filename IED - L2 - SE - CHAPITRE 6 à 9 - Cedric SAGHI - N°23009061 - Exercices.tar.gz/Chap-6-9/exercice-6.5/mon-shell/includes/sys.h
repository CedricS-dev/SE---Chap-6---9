/********************************************************
# Nom ......... : sys.h
# Rôle ........ : Fichier en-tête général du mini-shell
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 22/12/2025
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 5, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <assert.h>
#include <string.h>
#include <fcntl.h>
