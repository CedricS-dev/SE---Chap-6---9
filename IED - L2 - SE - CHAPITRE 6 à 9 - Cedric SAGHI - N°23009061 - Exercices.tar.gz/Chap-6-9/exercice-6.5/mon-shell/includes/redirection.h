/********************************************************
# Nom ......... : redirection.h
# Rôle ........ : Fichier en-tête de redirection.c
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 22/12/2025
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 5, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/


#ifndef _REDIRECTION_
#define _REDIRECTION_


/**
 * @brief cherche_redirection -- vérifie si une redirection est demandée et l'exécute
 * @param char *mots[] : liste de mots pouvant contenir une redirection
*/
void cherche_redirection(char *mots[]);


/**
 * @brief redirection -- exécute la redirection demandée
 * @param char **redirection : caractères de la redirection
 * @param char *filename : nom du fichier à ouvrir
 * @param int fileno : numéro d'id du flux, 3 pour rediriger stdout et stderr dans un fichier
 * @param int type_redir : type de redirection demandée :
 *     0 -> création de fichier / écrasement du contenu d'un fichier existant
 *     1 -> création d'un fichier / ajout de contenu si fichier existant
 *     2 -> ouverture d'un fichier en mode lecture
*/
void redirection(char ** redirection, char * filename, int fileno, int type_redir);


/**
 * @brief verifie_filename  -- vérifie si le nom de fichier qui suit la redirection est valide
 * @param char * redirection : redirection à vérifier
 * @param char * filename : nom de fichier à vérifier
 * @return int : 0 si aucun problème, -1 si erreur de nom de fichier
*/
int verifie_filename(char * redirection, char * filename);


#endif
