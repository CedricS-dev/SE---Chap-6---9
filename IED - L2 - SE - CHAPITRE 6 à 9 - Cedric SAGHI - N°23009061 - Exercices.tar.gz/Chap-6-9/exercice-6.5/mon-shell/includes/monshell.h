/********************************************************
# Nom ......... : monshell.h
# Rôle ........ : Fichier en-tête de monshell.c
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 29/01/2026
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 6, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/

#ifndef _MONSHELL_
#define _MONSHELL_


enum {
  MaxLigne = 1024,        // longueur max d'une ligne de commande
  MaxMot = MaxLigne / 2,  // nombre max de mot dans la ligne
};

#define PROMPT "? "


/**
 * @brief execute_commande_et_pipe -- execute une commande avec execvp(), ou plusieurs avec pipe
 * @param char *commandes[] : liste de commandes à exécuter
 * @param int nbr_commandes : nombre de commandes à exécuter
 * @param int *exit_status : pointeur vers le status de sortie de la commande précédente
*/
void execute_commande_et_pipe(char *commandes[], int nbr_commandes, int *exit_status);

#endif
