/********************************************************
# Nom ......... : utils.c
# Rôle ........ : Fichier contenant les fonctions utilitaires du mini-shell
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 29/01/2026
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 6, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/


#include "includes/sys.h"
#include "includes/utils.h"


int calcul_len(char *mots[])
{
	int i = 0;
	while(mots[i] != 0)
		i++;
	return i;
}


int decouper(char *ligne, char *separ, char *mots[], int maxmot)
{
	int i;

	mots[0] = strtok(ligne, separ);
	for(i = 1; mots[i - 1] != 0; i++)
	{
		if(i == maxmot)
		{
			fprintf(stderr, "Erreur dans la fonction découper: trop de mots\n");
			mots[i - 1] = 0;
			break;
		}
		mots[i] = strtok(NULL, separ);
	}
	return i;
}

void perror_exit(char *message)
{
	perror(message);
	exit(1);
}
