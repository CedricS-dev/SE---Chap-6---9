/********************************************************
# Nom ......... : command.c
# Rôle ........ : Fichier contenant les commandes natives du mini-shell
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 29/01/2026
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 6, L2 informatique
# (../..)
# Compilation : voir makefile
# Usage : Pour exécuter : ./monshell
#********************************************************/



#include "includes/sys.h"
#include "includes/command.h"


int cherche_esperluette(int len, char *liste_mots[])
{
  // Si le dernier caractère correspond à "&":
  // remplace ce "&" par NULL et retourne 0
  if (strcmp("&", liste_mots[len - 1]) == 0)
  {
    liste_mots[len - 1] = NULL;
    return 0;
  }

  return 1;
}


int cherche_commande(int len, char *mots[], int *exit_status)
{
	// Si la commande correspond à "moncd" ou "cd"
	if (strcmp("moncd", mots[0]) == 0 || strcmp("cd", mots[0]) == 0)
	{
		moncd(len, mots);
			return 1;
	}
	// Si la commande correspond à "monexit" ou "exit"
	if (strcmp("monexit", mots[0]) == 0 || strcmp("exit", mots[0]) == 0)
	{
		// Lance la fonction monexit()
		monexit(len, mots, *exit_status);	
			return 1;
	}

	return 0;
}

int moncd(int len, char *mots[])
{
	int t;
	char *dir;
		
	// Si la longueur est égale à 1, renvoie vers "HOME"
	if (len == 1)
		dir = getenv("HOME");
	// Si la longueur est supérieure à 2, c'est qu'il y a trop d'arguments,
	// retourne une erreur
	else if (len > 2)
	{
		fprintf(stderr, "Usage %s [dir]\n", mots[0]);
		return 1;
	}
	// Sinon, récupère le mot à l'indice 1	
	else
		dir = mots[1];

	// Et lance chdir
	t = chdir(dir);
	// Si le chdir a raté, retourne une erreur
	if (t < 0)
	{
		fprintf(stderr, "Erreur : le dossier %s n'a pas été trouvé\n", dir);
			return 1;
	}
	// Si le chdir a réussi, retourne 0
	return 0;
}


int monexit(int len, char *mots[], int exit_status)
{
	// Si la longueur est de 1, retourne le status de sortie de la dernère commande
	// 0 par défaut
	if(len == 1)
	{
		printf("Bye\n");
		exit(exit_status);
	}
	// Si la longueur est de 2, retourne la valeur à l’indice 1
	// Si la valeur n'est pas un nombre, atoi() retourne 0
	else if(len == 2)
	{
		// Convertis le nombre donné en int
		int i = atoi(mots[1]);
		printf("Bye\n");
		exit(i);
	}
	// Sinon, si la longueur est supérieure à 2
	// retourne une erreur et ne fait pas de exit()
	else if(len > 2)
	{
		fprintf(stderr, "Erreur : trop d'argument après %s\n", mots[0]);
		return 1;
	}
	
	return 0;
}
