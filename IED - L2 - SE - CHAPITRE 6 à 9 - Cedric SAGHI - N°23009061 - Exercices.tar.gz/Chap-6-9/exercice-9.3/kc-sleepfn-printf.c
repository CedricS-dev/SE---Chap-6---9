 /********************************************************
 # Nom ......... : kc-sleepfn-printf.c
 # Rôle ........ : Programme modifié kc-sleepfn.c pour imprimer un message
 # Auteur ...... : Cedric SAGHI
 # Version ..... : V0.1 du 23/02/2026
 # Licence ..... : réalisé dans le cadre du cours SE, chapitre 9, L2 informatique
 # (../..)
 # Compilation : gcc -Wall ka-sleep-args. kc-sleepfn-printf.c -o kasleep
 # Usage : Pour exécuter : ./kasleep
 #********************************************************/


#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>


void dring(int n)
{
  /* rien à faire */
}

unsigned int sleep(unsigned int nsec)
{  
  int avant, apres;
  
  avant = time(0);
  signal(SIGALRM, dring);
  alarm(nsec);
  pause();
  apres = time(0);
  printf("J'ai dormi %d secondes\n", nsec);
  return (avant + nsec) - apres;
}
