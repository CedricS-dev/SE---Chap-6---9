 /********************************************************
 # Nom ......... : ka-sleep-args.c
 # Rôle ........ : Programme modifié ka-sleep.c pour accepter un nombre fluctuant d'arguments
 # Auteur ...... : Cedric SAGHI
 # Version ..... : V0.1 du 23/02/2026
 # Licence ..... : réalisé dans le cadre du cours SE, chapitre 9, L2 informatique
 # (../..)
 # Compilation : gcc -Wall ka-sleep-args.c kc-sleepfn-printf.c -o kasleep
 # Usage : Pour exécuter : ./kasleep
 #********************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>


static void invalid(char *prog, char *s)
{
  fprintf(stderr, "%s: invalid time interval %s\n", prog, s);
  exit(1);
}


int main(int ac, char *av[])
{
  int i;
  int nsec;

  // Si il y a moins de 2 arguments, retourne une erreur
  if (ac < 2)
  {
    fprintf(stderr, "usage %s N\n", av[0]);
    return 1;
  }
  // Pour chaque argument à partir de l’indice 1
  for (int n = 1; n < ac; n++)
  {
    
    for (i = 0; isdigit(av[n][i]); i++)
      ;

    
    if (! isdigit(av[n][0]))
      invalid(av[0], av[n]);


    nsec = atoi(av[n]);
    switch(av[n][i])
    {
      default:
        invalid(av[0], av[n]);
      case 'd':
        nsec *= 24;
      case 'h':
        nsec *= 60;
      case 'm':
        nsec *= 60;
      case 's':
      case 0:
        ;
    }
    sleep(nsec);
  }  
  
  return 0;
}
