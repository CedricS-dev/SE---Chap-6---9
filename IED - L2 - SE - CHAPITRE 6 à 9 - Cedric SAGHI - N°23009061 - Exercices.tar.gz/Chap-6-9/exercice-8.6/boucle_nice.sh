#! /bin/bash
count=$1
i=1

while [ $i -le $count ];
do
  nice -n 19 ./ex86 &
  echo "$i"
  i=$(( $i + 1 ))
done
