int main()
{
  int x;
  for(;;)
    x += 1;
  return 0;
}
