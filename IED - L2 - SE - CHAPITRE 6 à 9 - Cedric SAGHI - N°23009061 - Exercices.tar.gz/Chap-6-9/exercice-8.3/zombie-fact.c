/********************************************************
# Nom ......... : zombie-fact.c
# Rôle ........ : Usine à zombies pour l'exercice 8.3
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 16/04/2026
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 8, L2 informatique
# (../..)
# Compilation : gcc -Wall zombie-fact.c -o zombie-fact
# Usage : Pour exécuter : ./zombie-fact
#********************************************************/


#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>


int main ()
{
  pid_t pid;
  int i;

  for (i = 0;  ; i++)
  {
    pid = fork();

    if (pid > 0)
    {
      printf("Zombie #%d born - parent PID %d\n", i + 1, getpid());
      usleep(1000);
    }
    else if (pid == 0)
      exit(0);
    else
    {
      perror("fork");
      exit(1);
    }
  }

  return 0;
}
