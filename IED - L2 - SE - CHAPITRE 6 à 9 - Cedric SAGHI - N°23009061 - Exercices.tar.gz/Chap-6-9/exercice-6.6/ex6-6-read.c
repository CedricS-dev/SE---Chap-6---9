/********************************************************
# Nom ......... : ex6-6-read.c
# Rôle ........ : Programme testant la lecture d'un pipe par deux processus enfants
# Auteur ...... : Cedric SAGHI
# Version ..... : V0.1 du 02/02/2026
# Licence ..... : réalisé dans le cadre du cours SE, chapitre 6, L2 informatique
# (../..)
# Compilation : gcc - Wall -o ex6-6-read.c -o exread
# Usage : Pour exécuter : ./exread
#********************************************************/


#include "sys.h"


int main()
{
  int fd[2];
  int t0, t1, t2;
  int tmp1, tmp2;
  char buff[1024];

  // Ouvre le pipe, et écris un message
  t0 = pipe(fd);
  assert(t0 >= 0);
 
  t0 = write(fd[1], "Message\n", 8);
  assert(t0 == 8);

  // Premier processus
  switch(tmp1 = fork())
  {
    // Erreur
    case -1:
      perror("Erreur : fork");
      exit(1);

   // Enfant :
   case 0:
     // Lecture par le premier enfant
     t1 = read(fd[0], buff, sizeof(buff));
       assert(t1 >= 0);

    buff[t1] = 0;
    printf("Lecture dans le premier enfant : %s", buff);
    
   default:
     break;     
  }
  // Deuxième processus
  switch(tmp2 = fork())
  {
    // Erreur
    case -1:
      perror("Erreur : fork");
      exit(1);

   // Enfant :
   case 0:
     // Lecture par le deuxième enfant
     t2 = read(fd[0], buff, sizeof(buff));
       assert(t2 >= 0);
       
    buff[t2] = 0;
    printf("Lecture dans le deuxième enfant : %s", buff);
 
   default:
     break;     
  }
  
  // Parent :
  // Attend que tous les processus enfants se terminent
  close(fd[0]);
  close(fd[1]);

  for (int i = 0; i < 2; i++)
    waitpid(-1, NULL, 0);

  return 0;
}
